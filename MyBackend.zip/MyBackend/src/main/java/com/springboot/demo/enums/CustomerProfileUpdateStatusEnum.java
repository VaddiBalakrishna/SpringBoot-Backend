package com.springboot.demo.enums;

public class CustomerProfileUpdateStatusEnum {

}
