package com.springboot.demo.enums;

public enum EmployeeAccessStatusEnum {
	GRANTED, DENIED, PENDING

}
