package com.springboot.demo.enums;

public enum RequsetStatusEnum {
	
	OPEN,IN_PROGRESS,COMPLETED,REJECTED, PENDING

}
